package com.example.avic.model;

public enum Service {
    RH,
    Comptabilite,
    Laboratoire,
    Secretariat,
    Medicale,
    Stock,
    Securité,
    Travaux_Interne


}
