package com.example.avic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvicApplicationTests {

    @Test
    void contextLoads() {
    }

}
